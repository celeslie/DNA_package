#' Fasta file with Danio rerio androgen receptor sequence.
#'
#'
#' @format A list with Fastadna data downloaded from GenBank
"DRseq"

#' Fasta file with Rana catesbeina androgen receptor sequence.
#'
#'
#' @format A list with Fastadna data downloaded from GenBank
"RCseq"

#' DNAbin file with aligned nucleotide sequences from 40 mammalian taxa
#'
#'
#' @format Aligned nucleotide sequences downloaded from Joe Felsenstein's website (url in vignette)
