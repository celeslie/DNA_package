## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
	warning = TRUE,
	message = TRUE,
  prompt = FALSE,
  fig.path = "img",
	fig.align = "center",
  fig.width=7
)

## ----eval=FALSE----------------------------------------------------------
#  library(DNAanalysis)

## ------------------------------------------------------------------------

library(seqinr)
library(curl)
library(ape)
library(phangorn)
library(ade4)


## ------------------------------------------------------------------------

dr <- curl("https://raw.githubusercontent.com/celeslie/DNA-Presentation/master/daniorerioAR.fasta")
DRseq <- read.fasta(dr)

rc <- curl("https://raw.githubusercontent.com/celeslie/DNA-Presentation/master/ranacatesbianaAR.fasta")
RCseq <- read.fasta(rc)


## ------------------------------------------------------------------------

DRseq <- DRseq[[1]]
RCseq <- RCseq[[1]]


## ------------------------------------------------------------------------

head(DRseq)
head(RCseq)
  # many manipulation functions require a single vector of individual characters.


## ------------------------------------------------------------------------

length(DRseq)
length(RCseq)


## ------------------------------------------------------------------------

table(DRseq)
table(RCseq)

# a,c,t, and g are the four nucleic acids, s indicates a strong interaction of c and g, y is a c,t, or u, and n is any nucleic acid.


## ------------------------------------------------------------------------
  #can also use a seqinr function to just get nucleotides

count(DRseq, 1)
count(RCseq, 1)


## ------------------------------------------------------------------------

(DR_cont <- count(DRseq, 1)/length(DRseq))
(RC_cont <- count(RCseq, 1)/length(RCseq))
  # despite different total nucleotide amounts, both organisms have about the same frequency of each nucleotide.  


## ------------------------------------------------------------------------

# zebrafish

(dr_words <- count(DRseq, 2, alphabet = s2c("acgt"))) # to get all possible 2-base combos

fCG <- dr_words[7]/(length(DRseq)-1) # frequency of CG

fGC <- dr_words[10]/(length(DRseq)-1) # frequency of GC


(CG_rho.dr <- fCG/ (DR_cont[2] * DR_cont[3]))
(GC_rho.dr <- fGC/ (DR_cont[3]*DR_cont[2]))

# alternatively, can use the rho() function from {seqinr}

(rho.dr <- rho(DRseq, wordsize = 2, alphabet = s2c("acgt")))

# bullfrog

(rho.rc <- rho(RCseq, wordsize = 2, alphabet = s2c("acgt")))


## ------------------------------------------------------------------------

# {seqinr} has a function to calculate the fraction of sequence that is GC, but not for CG. Here we create the equivalent function.

CG <- function(sequence) {
  
  tot <- count(sequence, wordsize = 2, alphabet = s2c("acgt"))
  cg <- tot[7]
  freq <- cg/sum(tot[1],tot[2],tot[3],tot[4],tot[5],tot[6],tot[7],tot[8],tot[9],tot[10],tot[11],tot[12],tot[13],tot[14],tot[15], tot[16])
  # print(freq)
  
} 


## ------------------------------------------------------------------------

#Sliding window plot function by Avril Coghlan (little book of r)
  #GC
swp.GC <- function(windowsize, inputseq)
{
   starts <- seq(1, length(inputseq)-windowsize, by = windowsize)
   n <- length(starts)    
   chunkGCs <- NULL 
   for (i in 1:n) {
        chunk <- inputseq[starts[i]:(starts[i]+windowsize-1)]
        chunkGC <- GC(chunk)
        chunkGCs[i] <- chunkGC
   }
   plot(starts,chunkGCs,type="b",xlab="Nucleotide start position",ylab="GC content")
}

  #CG
swp.CG <- function(windowsize, inputseq)
{
   starts <- seq(1, length(inputseq)-windowsize, by = windowsize)
   n <- length(starts)    
   chunkCGs <- NULL 
   for (i in 1:n) {
        chunk <- inputseq[starts[i]:(starts[i]+windowsize-1)]
        chunkCG <- CG(chunk)
        chunkCGs[i] <- chunkCG
   }
   plot(starts,chunkCGs,type="b",xlab="Nucleotide start position",ylab="CG content")
}


## ------------------------------------------------------------------------

par(mfrow=c(1,2))
swp.GC(100, DRseq)
swp.GC(100, RCseq)
swp.CG(100, DRseq)
swp.CG(100, RCseq)


## ----eval=FALSE----------------------------------------------------------
#  
#  dotPlot(DRseq, RCseq)
#  

## ------------------------------------------------------------------------

f <- curl("https://raw.githubusercontent.com/celeslie/DNA-Presentation/master/ADAM7.dna")
adam7<-read.dna(f, format="interleaved")


## ------------------------------------------------------------------------

adam7_phydat<-phyDat(adam7, type="DNA", levels=NULL)


## ------------------------------------------------------------------------

adam7_10<-subset(adam7_phydat, 1:10)
adam7_10_phydat<-phyDat(adam7_10, type="DNA", levels=NULL)


## ------------------------------------------------------------------------

adam7_10_dna<-as.DNAbin(adam7_10) #converts subsetted phydat object back into DNAbin format

dist_adam7_dna<-dist.dna(adam7_10_dna, model="raw")
dist_adam7_dna


## ------------------------------------------------------------------------
adam7_upgma <- upgma(dist_adam7_dna)
plot(adam7_upgma, main="UPGMA")

## ------------------------------------------------------------------------

parsimony(adam7_upgma, adam7_10)


## ------------------------------------------------------------------------

adam7_nj <- NJ(dist_adam7_dna)
plot(adam7_nj, "unrooted", main="Neighbor Joining")


## ------------------------------------------------------------------------

parsimony(adam7_nj, adam7_10)


## ------------------------------------------------------------------------

adam7_optim<-optim.parsimony(adam7_nj, adam7_10)
plot(adam7_optim)
parsimony(adam7_optim, adam7_10)


## ------------------------------------------------------------------------

adam7_pratchet<-pratchet(adam7_10)
plot(adam7_pratchet)
parsimony(adam7_pratchet, adam7_10)


## ------------------------------------------------------------------------

DIST <- as.data.frame(as.matrix(dist_adam7_dna))

table.paint(DIST, cleg=0, clabel.row=0.5, clabel.col=0.5)
  #darker shades of grey represent greater distances

#can make into a prettier plot using image()

Dist <- t(as.matrix(dist_adam7_dna))
Dist <- Dist[,ncol(Dist):1]

image(x=1:10, y=1:10, Dist, col=heat.colors(100), xaxt="n", yaxt="n", xlab="",ylab="")
axis(side=2, at=1:10, lab=rev(rownames(adam7_10_dna)), las=2, cex.axis=.5)
axis(side=3, at=1:10, lab=rownames(adam7_10_dna), las=3, cex.axis=.5)
  #here, darker shades are more similar (closer)


## ------------------------------------------------------------------------
# This block of R code will be foldable after knitting

